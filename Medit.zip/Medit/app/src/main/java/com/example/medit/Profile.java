package com.example.medit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.database.CharArrayBuffer;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Profile extends AppCompatActivity {
    private DBHelper mydb;
    //private showDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        mydb = new DBHelper(this);
        /*Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            String usern = bundle.getString("username");

            readUser(usern);
        }*/
        /*Button b1 = (Button)findViewById(R.id.viewDetails);
        b1.setOnClickListener( new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                //showDetails();
            }
        });*/
        //for showing msg
        //************second way*************
        Intent Extra = getIntent();
        String usernm = Extra.getStringExtra("Username");
        String fulnm = Extra.getStringExtra("fullname");
        String emailO = Extra.getStringExtra("email");
        String dbO = Extra.getStringExtra("date_birth");


        TextView UserInput = (TextView) findViewById(R.id.userNameOutput);
        UserInput.setText(usernm);
        UserInput.setText(fulnm);
        UserInput.setText(emailO);
        UserInput.setText(dbO);




        final Button button = (Button) findViewById(R.id.viewDetails);
        button.setOnClickListener(v -> {
            showDetails();
            Intent intent = new Intent(Profile.this, Profile.class);
            startActivity(intent);
        });

        //**************third way************
        /*TextView usName,emailO;
        Button viewDet;
        DBHelper myDb;
        usName = (TextView) findViewById(R.id.userNameOutput);
        emailO = (TextView) findViewById(R.id.emailOutput);
        viewDet = (Button) findViewById(R.id.viewDetails);
        myDb =  new DBHelper(this);
        viewDet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res = myDb.getData();
                if (res.getCount() ==0){
                    findViewById(R.id.userNameOutput).setText("");
                    Toast.makeText(SEARCH2.this,"DATA NOT FOUND",Toast.LENGTH_LONG).show();
                    return;
                }
                res.moveToNext();
                etSMark.setText(res.getString(2));
                Toast.makeText(Profile.this,"DATA NOT FOUND",Toast.LENGTH_LONG).show();
            }
        });*/
    }

    public void plan(View v) {
        final TextView plan = (TextView) findViewById(R.id.plan_link_button);
        plan.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v1) {
                Intent launchActivity2 = new Intent(Profile.this, planner.class);
                startActivity(launchActivity2);
            }
        });
    }


    public void showDetails(){
        TextView fullNameOutput = (TextView) findViewById(R.id.fullNameOutput);
        TextView emailOutput = (TextView) findViewById(R.id.emailOutput);
        TextView dateOutput = (TextView) findViewById(R.id.dateOutput);
        TextView userNameOutput = (TextView) findViewById(R.id.userNameOutput);


        Cursor cursor = mydb.getData();

        String fullname="";
        String email="";
        String date="";
        String usern="";
        boolean isFound=false;

        if(cursor.moveToFirst()){
            int i=0;
            do{

                fullname =cursor.getString(cursor.getColumnIndex(DBHelper.USERS_FIRSTNAME+DBHelper.USERS_LASTNAME));
                email=cursor.getString(cursor.getColumnIndex(DBHelper.USERS_EMAIL));
                date=cursor.getString(cursor.getColumnIndex(DBHelper.USERS_DOB));
                usern =cursor.getString(cursor.getColumnIndex(DBHelper.USERS_USERNAME));
                Toast.makeText(getApplicationContext(),"Your details are: Username"+usern+
                        "Email:"+email+"Date of Birth:"+date+"Fullname:"+fullname, Toast.LENGTH_SHORT);



                i++;


            }while (cursor.moveToNext());
        }

    }

    /*public void readUser(String username) {
       // Toast.makeText(getApplicationContext(), "read user function " + username, Toast.LENGTH_SHORT).show();
        Cursor cursor = mydb.getData();

        // String userid="";
        String usern = "";

        boolean isFound = false;

        /*if (cursor.moveToFirst()) {
            int i = 0;
            do {

                usern = cursor.getString(cursor.getColumnIndex(DBHelper.USERS_USERNAME));


                if (usern.equals(username)) {
                    Toast.makeText(getApplicationContext(), "Hi " + usern, Toast.LENGTH_SHORT).show();
                    TextView b = (TextView) findViewById(R.id.usernamep);
                    b.setText("Hello "+usern);
                    break;
                }
                i++;


            } while (cursor.moveToNext());

        //}


    } */

    public void landpage1(View v)
    {
        final ImageView imageButton1;
        imageButton1 = (ImageView) findViewById(R.id.imageButton1);
        imageButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent launchActivity5 = new Intent(Profile.this, MainActivity.class);
                startActivity(launchActivity5);
            }
        });
    }

    public void logout(View v)
    {
        final TextView logout=(TextView)findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v1) {
                Intent launchActivity6= new Intent(Profile.this,MainActivity.class);
                startActivity(launchActivity6);
                Toast.makeText(getApplicationContext(),"You have successfully logged out.", Toast.LENGTH_SHORT).show();

            }
        });
    }
}
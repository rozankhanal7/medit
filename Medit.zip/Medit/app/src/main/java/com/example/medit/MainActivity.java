package com.example.medit;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    private DBHelper mydb ;
    int id_To_Update = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mydb = new DBHelper(this);

        Button b = (Button)findViewById(R.id.login);
        b.setOnClickListener( new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                 // TODO Auto-generated method stub
                readUser();
            }
        });
    }
    public void readUser(){
        EditText username = (EditText)findViewById(R.id.username);
        EditText password = (EditText)findViewById(R.id.password);
        Cursor cursor = mydb.getData();

        String userid="";
        String usern="";
        String passd="";
        boolean isFound=false;

        if(cursor.moveToFirst()){
            int i=0;
            do{

                usern=cursor.getString(cursor.getColumnIndex(DBHelper.USERS_USERNAME));
                passd=cursor.getString(cursor.getColumnIndex(DBHelper.USERS_PASSWORD));


                if(usern.equals(username.getText().toString()) && passd.equals(password.getText().toString()) && !username.getText().toString().equals("")) {


                    Toast.makeText(getApplicationContext(), "You have logged in successfully", Toast.LENGTH_SHORT).show();
                    isFound=true;
                    Intent intent = new Intent(getApplicationContext(),Profile.class);
                    intent.putExtra("username",usern);
                    startActivity(intent);
                    break;
                }
                i++;


            }while (cursor.moveToNext());
        }

        if(!isFound) {
            Toast toast=Toast.makeText(getApplicationContext(), "Invalid username or password", Toast.LENGTH_SHORT);
            toast.getView().setBackgroundColor(Color.parseColor("#F6AE2D"));
            toast.show();
        }



    }

    /*public void createNotification (View view) {
        Intent myIntent = new Intent(getApplicationContext() , NotifyService. class ) ;
        AlarmManager alarmManager = (AlarmManager) getSystemService( ALARM_SERVICE ) ;
        PendingIntent pendingIntent = PendingIntent. getService ( this, 0 , myIntent , 0 ) ;
        Calendar calendar = Calendar. getInstance () ;
        calendar.set(Calendar. SECOND , 0 ) ;
        calendar.set(Calendar. MINUTE , 0 ) ;
        calendar.set(Calendar. HOUR , 0 ) ;
        calendar.set(Calendar. AM_PM , Calendar. AM ) ;
        calendar.add(Calendar. DAY_OF_MONTH , 1 ) ;
        alarmManager.setRepeating(AlarmManager. RTC_WAKEUP , calendar.getTimeInMillis() , 1000 * 60 * 60 * 24 , pendingIntent) ;
    }*/


    public void login(View v)
    {
        final TextView login=(TextView)findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v1) {
                Intent launchActivity3= new Intent(MainActivity.this, Profile.class);
                startActivity(launchActivity3);

            }
        });

    }

    public void register(View v)
    {
        final TextView register=(TextView)findViewById(R.id.register);
        register.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v1) {
                Intent launchActivity1= new Intent(MainActivity.this,register.class);
                startActivity(launchActivity1);

            }
        });
    }

    public void landpage(View v)
    {
        final ImageButton imageButton=(ImageButton)findViewById(R.id.imageButton);
        imageButton.setOnClickListener(new View.OnClickListener() {
                                           @Override
                                           public void onClick(View v) {
                                               Intent launchActivity4 = new Intent(MainActivity.this, MainActivity.class);
                                               startActivity(launchActivity4);
                                           }
                                       }



        );
    }


}
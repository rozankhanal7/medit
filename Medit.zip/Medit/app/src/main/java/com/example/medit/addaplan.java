package com.example.medit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.renderscript.RenderScript;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.PriorityQueue;

import static androidx.core.app.NotificationCompat.PRIORITY_DEFAULT;

public class addaplan extends AppCompatActivity {
    private static final String CHANNEL_ID = "2";
    int id_To_Update = 0;
    //@SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addaplan);
        createNotificationChannel();



        Spinner dropdown = findViewById(R.id.plan_type_spinner);
        String[] items = new String[]{"Medication", "Daily Activities", "Appointment"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        dropdown.setAdapter(adapter);

        Spinner dropdown1;
        dropdown1 = findViewById(R.id.frequency);
        String[] items1 = new String[]{"Daily", "In Two Days", "Weekly", "Fortnightly", "Monthly"};
        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items1);
        dropdown1.setAdapter(adapter1);




        mydb1 = new DBPlanner(this);

        Button b1 = (Button)findViewById(R.id.add_button);
        b1.setOnClickListener(v ->  {


                // TODO Auto-generated method stub
                readPlan();

        });
        Button b = (Button) findViewById(R.id.notify);


        // TODO Auto-generated method stub
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "VU")
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("Your Plan")
                .setContentText("You have a plan on schedule:"+ DBPlanner.PLAN_TIME)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        NotificationManagerCompat notificationManager=NotificationManagerCompat.from(this);
        b.setOnClickListener(v -> {
            notificationManager.notify(120,builder.build());
        });


    }
    private DBPlanner mydb1 ;
    int plan_id_To_Update = 0;


    public void readPlan(){
        Spinner mySpinner = (Spinner) findViewById(R.id.plan_type_spinner);
        String plan_type = mySpinner.getSelectedItem().toString();
        EditText plan_description = (EditText) findViewById(R.id.plan_description);
        Spinner mySpinner1 = (Spinner) findViewById(R.id.frequency);
        String plan_frequency = mySpinner1.getSelectedItem().toString();
        EditText plan_date = (EditText) findViewById(R.id.plan_date);
        EditText plan_time = (EditText) findViewById(R.id.plan_time);



        Cursor cursor = mydb1.getDataPlan();

        String plntype="";
        String pln_d="";
        String pln_f="";
        String pln_date="";
        String pln_time="";
        boolean isFound=false;

        if(cursor.moveToFirst()){
            int i=0;
            do{
                plntype=cursor.getString(cursor.getColumnIndex(DBPlanner.PLAN_TYPE));
                pln_d=cursor.getString(cursor.getColumnIndex(DBPlanner.PLAN_DESCRIPTION));
                pln_f=cursor.getString(cursor.getColumnIndex(DBPlanner.PLAN_FREQUENCY));
                pln_date=cursor.getString(cursor.getColumnIndex(DBPlanner.PLAN_DATE));
                pln_time=cursor.getString(cursor.getColumnIndex(DBPlanner.PLAN_TIME));



                if(plntype.equals(plan_type.toString()) && pln_d.equals(plan_description.getText().toString()) && pln_f.equals(plan_frequency) && pln_date.equals(plan_date.getText().toString()) && pln_time.equals(plan_time.getText().toString())&& !pln_d.equals("")) {
                    Toast.makeText(getApplicationContext(), "You have successfully created a plan.", Toast.LENGTH_SHORT).show();
                    isFound=true;
                    //Intent intent = new Intent(getApplicationContext(),planner.class);
                    //startActivity(intent);
                    break;
                }
                i++;
            }while (cursor.moveToNext());
        }
        if(!isFound) {
            Toast toast=Toast.makeText(getApplicationContext(), "Please enter a valid plan", Toast.LENGTH_SHORT);
            toast.getView().setBackgroundColor(Color.parseColor("#F6AE2D"));
            toast.show();
        }

    }


    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "My_Channel";
            String description = "Test only";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("VU", name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
}
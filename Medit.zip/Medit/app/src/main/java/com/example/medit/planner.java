package com.example.medit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class planner extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_planner);
    }
    public void add1(View v)
    {
        final TextView add_a_plan=(TextView)findViewById(R.id.add_a_plan_button);
        add_a_plan.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v1) {
                Intent launchActivity1= new Intent(planner.this,addaplan.class);
                startActivity(launchActivity1);

            }
        });
    }
}
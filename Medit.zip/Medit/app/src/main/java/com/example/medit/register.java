package com.example.medit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class register extends AppCompatActivity {
    private DBHelper mydb ;
    private Bundle savedInstanceState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mydb = new DBHelper(this);

        Button b = (Button)findViewById(R.id.createUser);
        b.setOnClickListener( new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                addNew();
            }
        });

        mydb = new DBHelper(this);

        Button b1 = (Button)findViewById(R.id.btnUpdate);
        b1.setOnClickListener( new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                update();
            }
        });
    }

    public void addNew(){
        EditText usernm=(EditText)findViewById(R.id.username);
        EditText fname=(EditText)findViewById(R.id.firstname);
        EditText lname=(EditText)findViewById(R.id.lastname);
        EditText email=(EditText)findViewById(R.id.email);
        EditText passwd=(EditText)findViewById(R.id.password);
        EditText dob=(EditText)findViewById(R.id.T3);

        Bundle extras = getIntent().getExtras();
        //for troubleshooting
        //Toast.makeText(getApplicationContext(), usernm.getText().toString()+""+fname.getText().toString()+" "+ lname.getText().toString()+" "+ email.getText().toString()+" "+passwd.getText().toString(), Toast.LENGTH_SHORT).show();

        int usernO = R.string.username;
        int fulnm = R.string.first_name;
        int emailO = R.string.email_entry;
        int dobO = R.string.date_birth;

        if(mydb.insertUser(usernm.getText().toString(), fname.getText().toString(), lname.getText().toString(), email.getText().toString(), passwd.getText().toString(), dob.getText().toString())){
            Toast.makeText(getApplicationContext(), "A new account has been created",Toast.LENGTH_SHORT).show();
            Intent sendMessage = new Intent(register.this,     Profile.class);
            sendMessage.putExtra("Username", usernO);
            sendMessage.putExtra("fullname", fulnm);
            sendMessage.putExtra("email", emailO);
            sendMessage.putExtra("date_births", dobO);

            startActivity(sendMessage);
        } else{
            Toast.makeText(getApplicationContext(), "not done", Toast.LENGTH_SHORT).show();
        }
        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(intent);


    }
    public void update(){
        EditText usernm=(EditText)findViewById(R.id.username);
        EditText fname=(EditText)findViewById(R.id.firstname);
        EditText lname=(EditText)findViewById(R.id.lastname);
        EditText email=(EditText)findViewById(R.id.email);
        EditText passwd=(EditText)findViewById(R.id.password);
        EditText dob=(EditText)findViewById(R.id.T3);
        int id = 0;
        id++;

        Bundle extras = getIntent().getExtras();
        //for troubleshooting
        //Toast.makeText(getApplicationContext(), usernm.getText().toString()+""+fname.getText().toString()+" "+ lname.getText().toString()+" "+ email.getText().toString()+" "+passwd.getText().toString(), Toast.LENGTH_SHORT).show();

        int usernO = R.string.username;
        int fulnm = R.string.first_name;
        int emailO = R.string.email_entry;
        int dobO = R.string.date_birth;

        if(mydb.updateLogin(id, usernm.getText().toString(), fname.getText().toString(), lname.getText().toString(), email.getText().toString(), passwd.getText().toString(), dob.getText().toString())){
            Toast.makeText(getApplicationContext(), "Your account has been updated",Toast.LENGTH_SHORT).show();
            Intent sendMessage = new Intent(register.this,     Profile.class);
            sendMessage.putExtra("Username", usernO);
            sendMessage.putExtra("fullname", fulnm);
            sendMessage.putExtra("email", emailO);
            sendMessage.putExtra("date_births", dobO);

            startActivity(sendMessage);
        } else{
            Toast.makeText(getApplicationContext(), "Please enter the details again", Toast.LENGTH_SHORT).show();
        }
        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(intent);
    }


}
package com.example.medit;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Spinner;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBPlanner extends SQLiteOpenHelper {
    //plan type database
    public static final String DATABASE2_NAME = "plan.db";
    public static final String PLAN_TABLE_NAME = "planner";
    public static final String PLAN_COL_ID = "plan_id";
    public static final String PLAN_TYPE = "plan_type";
    public static final String PLAN_DESCRIPTION = "plan_description";
    public static final String PLAN_FREQUENCY = "plan_frequency";
    public static final String PLAN_DATE = "plan_date";
    public static final String PLAN_TIME = "plan_time";


    public DBPlanner(Context context) {
        super(context, DATABASE2_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "create table planner " +
                        "(plan_id integer primary key, plan_type text, plan_description text, plan_frequency text, plan_date text, plan_time text )"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS planner");
        onCreate(db);
    }

    public boolean insertPlan(Spinner plan_type, String plan_description, Spinner plan_frequency, String plan_date, String plan_time) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("plan_type", String.valueOf(plan_type));
        contentValues.put("plan_description", plan_description);
        contentValues.put("plan_frequency", String.valueOf(plan_frequency));
        contentValues.put("plan_date", plan_date);
        contentValues.put("plan_time", plan_time);


        db.insert("planner", null, contentValues);
        return true;
    }

    public Cursor getDataPlan() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from planner ", null );
        return res;
    }

    public int numberOfRows_Plan(){
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows_plan = (int) DatabaseUtils.queryNumEntries(db, PLAN_TABLE_NAME);
        return numRows_plan;
    }
    public boolean updatePlan (Integer plan_id, Spinner plan_type, String plan_description, Spinner plan_frequency, String plan_date, String plan_time) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("plan_type", String.valueOf(plan_type));
        contentValues.put("plan_description", plan_description);
        contentValues.put("plan_frequency", String.valueOf(plan_frequency));
        contentValues.put("plan_date", plan_date);
        contentValues.put("plan_time", plan_time);


        db.update("planner", contentValues, "id = ? ", new String[] { Integer.toString(plan_id) } );
        return true;
    }

    public Integer deletePlan (Integer plan_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("planner",
                "plan_id = ? ",
                new String[] { Integer.toString(plan_id) });
    }

    public ArrayList<String> getAllPlan() {
        ArrayList<String> array_list = new ArrayList<String>();

        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from planner", null );
        res.moveToFirst();

        while(!res.isAfterLast()){
            array_list.add(res.getString(res.getColumnIndex(PLAN_TYPE)));
            res.moveToNext();
        }
        return array_list;
    }
}

